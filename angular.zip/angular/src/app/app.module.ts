import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TradeComponent } from './components/trade/trade.component';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BsDatepickerModule }   from 'ngx-bootstrap/datepicker';
import {BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AllListComponent } from './components/all-list/all-list.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgxPaginationModule } from 'ngx-pagination';
import { tradeNameFilterPipe } from './models/tradeNameFilter';

@NgModule({
  declarations: [
    AppComponent,
    TradeComponent,
    AllListComponent,
    tradeNameFilterPipe

  ],
  imports: [
    
    //RouterModule,
    BrowserModule,
    Ng2SearchPipeModule,
    
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    

    
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
