import { PipeTransform, Pipe } from '@angular/core';
import { tradeInfo } from './tradeInfo';

@Pipe({
    name: 'tradeNameFilter'
})
export class tradeNameFilterPipe implements PipeTransform {
    transform(infoes: tradeInfo[], searchTerm: string): tradeInfo[] {
        if (!infoes || !searchTerm) {
            return infoes;
        }

        return infoes.filter(x =>
            x.tradeName.toUpperCase().indexOf(searchTerm.toUpperCase()) !== -1);
    }
}