export class trade
{
    id:Number;
    tradeName:string;
}