export class tradeInfo
{
    id:Number;
    tradeName:string;
    levelName:string;
    language:string;
    syllabus:string;
    syllabusFileName:string;
    testPlanFileName:string;
    developmentOfficer:string;
    manager:string;
    active:Date;
    syllabusFilePath:string;
    testPlanFilePath:string;
}