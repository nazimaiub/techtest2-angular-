export class level
{
    id:Number;
    levelName:string;
    tradeId:Number;
}