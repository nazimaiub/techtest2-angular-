export class language
{
    id:Number;
    langName:string;
}