import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';
import { tradeInfo } from 'src/app/models/tradeInfo';
import { saveAs } from 'file-saver';
import { trade } from 'src/app/models/trade';
import { level } from 'src/app/models/level';
@Component({
  selector: 'app-all-list',
  templateUrl: './all-list.component.html',
  styleUrls: ['./all-list.component.scss']
})
export class AllListComponent implements OnInit {
  searchTerm:string;
  tradeList:tradeInfo[];
  tradeListdrp:tradeInfo[];
  levelListdrp:level[];
  trades:trade[];
  p:number=1;
  tradeSearch:string;
  tradeId:Number;
  trade=null;
  levelList:level[];
  levelId:Number;
  level=null;
  constructor(private dataService:DataService) { }

  ngOnInit(): void {
    this.getAlltradeInfoes();
    this.getTrades();
  }
  getTrades()
  {
    this.dataService.getAllTrades().subscribe((result:any)=>{
      this.trades=result;
      //.log(JSON.stringify(this.tradeList));
      this.setTrades(this.trades);    
    });

  }
  setTrades(result)
  {

    this.trades=result;
  }
  getAlltradeInfoes()
  {
    this.dataService.getAlltradeInfoes().subscribe((result:any)=>{
      this.tradeList=result;
      
      this.setTradelist(this.tradeList);    
    });

  }
  setTradelist(result)
  {
    this.tradeList=result;
    this.tradeListdrp=result;
  }
  getLevelList(value)
  {
    let tradeId=this.trades.find(x=>x.tradeName==value).id;
  this.level=null;
    this.tradeId=parseInt(value);
    this.dataService.getAllLevelsByTradeId(tradeId).subscribe((result:any)=>{
      this.levelList=result;
      this.setLevellist(this.levelList);    
    });
  }
  setLevellist(result)
  {

    this.levelList=result;
    //this.levelListdrp=result;
  }
  syllabusDownload(index)
  {
    var filepath=this.tradeList[index].syllabusFilePath;
     var filename=this.tradeList[index].syllabusFileName;
    saveAs(filepath,filename);
    

  }
  searchByTrade(value)
  {
    //let tradeName:string=this.trades.find(x=>x.id==value).tradeName;
    this.tradeList=this.tradeListdrp.filter(x=>x.tradeName==value);
    this.getLevelList(value);

  }
  searchByLevel(value)
  {
    this.tradeList=this.tradeListdrp.filter(x=>x.levelName==value);
  }
  tradeSearchValuechange(newvalue)
  {
    this.tradeList = this.tradeList.filter(
      (val)=> val['tradeName'].includes(newvalue));
      if(!newvalue){
        this.getAlltradeInfoes();
    } // when nothing has typed
    this.tradeList = Object.assign([], this.tradeList).filter(
       item => item.tradeName.toLowerCase().indexOf(newvalue.toLowerCase()) > -1
    )

  }
  
  testDownload(index)
  {
    var filepath=this.tradeList[index].testPlanFilePath;
    var filename=this.tradeList[index].testPlanFilePath;
    saveAs(filepath,filename);
  }

  }


