import { Component, OnInit } from '@angular/core';
import { trade } from 'src/app/models/trade';
import { DataService } from 'src/app/services/data.service';
import { Router } from '@angular/router';
import { level } from 'src/app/models/level';
import { language } from 'src/app/models/language';
import { NgForm } from '@angular/forms';
import { BsDatepickerConfig }   from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-trade',
  templateUrl: './trade.component.html',
  styleUrls: ['./trade.component.scss']
})
export class TradeComponent implements OnInit {
  tradeList:trade[];
  tradeId:Number;
  trade=null;
  levelList:level[];
  levelId:Number;
  level=null;
  langList:language[];
  activedate=new Date();
  datePickerConfig:Partial<BsDatepickerConfig>;
  fileToUploadSyllabus: File = null;
  fileToUploadTestPlan: File = null;
  lang:string="";
  message: string;
  resStyle:string;
  resStatus:boolean=false;
  constructor(private dataService:DataService,private router:Router) { 
    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-blue',
        showWeekNumbers: false,
        dateInputFormat: 'DD/MM/YYYY'
      });
  }

  ngOnInit(): void {
    this.getTradeList();
    this.getLanguageList();
    this.message="";
  }
  handleSyllabusFileInput(files: FileList) {
    this.fileToUploadSyllabus = files.item(0);
}
handleTestPlanFileInput(files: FileList) {
  this.fileToUploadTestPlan = files.item(0);
}
  getTradeList()
  {
    this.dataService.getAllTrades().subscribe((result:any)=>{
      this.tradeList=result;
      console.log(JSON.stringify(this.tradeList));
      this.setTradelist(this.tradeList);    
    });

  }
  setTradelist(result)
  {

    this.tradeList=result;
  }

  getLanguageList()
  {
    this.dataService.getAllLanguages().subscribe((result:any)=>{
      this.langList=result;
      this.setLanguagelist(this.langList);    
    });

  }
  setLanguagelist(result)
  {

    this.langList=result;
  }
  

  getLevelList(value)
  {
    this.level=null;
    this.tradeId=parseInt(value);
    this.dataService.getAllLevelsByTradeId(this.tradeId).subscribe((result:any)=>{
      this.levelList=result;
      this.setLevellist(this.levelList);    
    });
  }
  setLevellist(result)
  {

    this.levelList=result;
  }
  OnSubmit(form:NgForm)
  {
    
    
    this.dataService.save(form,this.lang,this.fileToUploadSyllabus,this.fileToUploadTestPlan).subscribe((result:any)=>{

      //this.levelList=result;
      //this.setLevellist(this.levelList); 
      this.setStatus(result);
        
    });


  }
  setStatus(result)
  {
    this.resStatus=true;
    if(result==0)
    {

      this.message = "Item Not Inserted";
      this.resStyle="alert alert-danger";
    }
    else{
      this.message = "Item Inserted Successfully";
      this.resStyle="alert alert-success";

    }
    console.log(this.message);
    document.getElementById("openerrorModalButton").click();
    

  }
  onClicked(event) {
    if( event.target.checked==false)
    {
      var str = this.lang;
      var res = str.split(event.target.value + ',');
      
      this.lang = res.toString();
      
    }
    else{
      this.lang += event.target.value+ ',';;

    }
    
   
    //console.log("event  checked" + this.lang);
   
    var langId=parseInt(event.target.value);
  }

  AllList()
  {
    this.router.navigate(['allList']);
  }
}
