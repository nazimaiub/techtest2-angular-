import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { trade } from '../models/trade';
import { level } from '../models/level';
import { language } from '../models/language';
import { NgForm } from '@angular/forms';
import { tradeInfo } from '../models/tradeInfo';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient ) { }
  getAllTrades():Observable<trade>
  {
    console.log("ok");
    return this.http.get<trade>("https://localhost:44384/api/GetAllTrades");

  }
  getAllLevelsByTradeId(tradeId:Number):Observable<level>
  {
    //console.log(id);
    return this.http.get<level>("https://localhost:44384/api/GetAllLevelsBytradeId?tradeId="+tradeId);
   
  }
  getAllLanguages():Observable<language>
  {
    //console.log(id);
    return this.http.get<language>("https://localhost:44384/api/GetLanguages");

  }
  getAlltradeInfoes():Observable<tradeInfo>
  {
    //console.log(id);
    return this.http.get<tradeInfo>("https://localhost:44384/api/getAllList");

  }



  save(form:NgForm,lang:string,sfile?:File,tfile?:File)
  {
    const formData: FormData = new FormData();
    //console.log(form.controls['tradeId'].value);
    ///console.log(form.controls['level'].value);
    //console.log(form.controls['level'].value);
    formData.append('tradeId',form.controls['tradeId'].value);
    formData.append('levelName',form.controls['levelId'].value);
    formData.append('langName',lang);
    formData.append('syllabus',form.controls['syllabus'].value);
    if(sfile!=null)
    {
    formData.append('fileToUploadSyllabus',sfile,sfile.name);
    }
    if(tfile!=null)
    {
    formData.append('fileToUploadTestPlan',tfile,tfile.name);
    }
    formData.append('officer',form.controls['officer'].value);
    formData.append('manager',form.controls['manager'].value);
    var datestr = (new Date(form.controls['activedate'].value)).toUTCString();
    formData.append('active',datestr);
    

    console.log(formData.get("tradeId"));
    console.log(formData.get("levelName"));
    console.log(formData.get("langName"));
    console.log(formData.get("syllabus"));
    console.log(formData.get("officer"));
    console.log(formData.get("manager"));
    

    // let headers = new HttpHeaders({
    //   'Content-Type': 'multipart/form-data'
    // });
    // let options = { headers: headers };
    return this.http.post<string>("https://localhost:44384/api/Save", formData);

  }
}
